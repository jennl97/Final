//: Playground - noun: a place where people can play

import UIKit
import Foundation

// SPRINT 2
//  step 1: customer downloads app
//  step 2: customer instructed to input phone number.
//  once phone number entered, message will display phone number and ask to verify if correct
//  step 3: customer selects yes or no

//variables

var phone="335-678-1234"

// Set the pattern

//let pat = "\\^[2-9]\\d{2}-\\d{3}-\\d{4}$"
let pat = "[2-9][0-9]{2}-[0-9]{3}-[0-9]{4}"
let testStr = "800-555-5555, 815-333-5555"
let regex = try NSRegularExpression(pattern: pat, options: [])
let matches = regex.matchesInString(phone, options: [], range: NSRange(location: 0, length: phone.characters.count))

// checking for matches

for match in matches {
    for n in 0..<match.numberOfRanges{
        let range = match.rangeAtIndex(n)
        let r = phone.startIndex.advancedBy(range.location) ..<
            phone.startIndex.advancedBy(range.location+range.length)
            phone.substringWithRange(r)
        print(phone.substringWithRange(r)," Is this correct? Y or N?")
      
   }
    
}

var y = true
var n = false
var answer:Bool

let rand = arc4random_uniform(100)
if(rand<50) {answer = true} else { answer = false}

if answer==true{
    print("Welcome to the Surgical Update Network")
    
}
else{
    print("Please enter phone number")
}





