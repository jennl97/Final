//: Playground - noun: a place where people can play

import UIKit
import Foundation

// SPRINT 2
//  step 1: customer downloads app
//  step 2: customer instructed to input phone number.
//  once phone number entered, message will display phone number and ask to verify if correct
//  step 3: customer selects yes or no

//variables

var phone=""

// Set the pattern

let pat = "\\^[2-9]\\d{2}-\\d{3}-\\d{4}$"
let testStr = "800-555-5555, 815-333-5555"
let regex = try! NSRegularExpression(pattern: pat, options: [])
let matches = regex.matchesInString(testStr, options: [], range: NSRange(location: 0, length: testStr.characters.count))

// checking for matches

for match in matches {
    for n in 0..<match.numberOfRanges{
        let range = match.rangeAtIndex(n)
        let r = testStr.startIndex.advancedBy(range.location) ..<
            testStr.startIndex.advancedBy(range.location+range.length)
            testStr.substringWithRange(r)
      
   }
}




