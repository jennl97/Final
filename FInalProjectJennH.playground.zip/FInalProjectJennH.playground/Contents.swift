//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//:SPRINT 2
//: step 1: customer downloads app
//: step 2: customer instructed to input phone number.
//: once phone number entered, message will display phone number and ask to verify if correct
//: step 3: customer selects yes or no

var phone=""

