//: Playground - noun: a place where people can play

import UIKit
import Foundation

// SPRINT 2
//  step 1: customer downloads app
//  step 2: customer instructed to input phone number.
//  once phone number entered, message will display phone number and ask to verify if correct
//  step 3: customer selects yes or no

//variables

var phone="335-678-1234"

// Set the pattern
//let pat = "\\^[2-9]\\d{2}-\\d{3}-\\d{4}$"
let pat = "[2-9][0-9]{2}-[0-9]{3}-[0-9]{4}"
let testStr = "800-555-5555, 815-333-5555"
let regex = try NSRegularExpression(pattern: pat, options: [])
let matches = regex.matchesInString(phone, options: [], range: NSRange(location: 0, length: phone.characters.count))

// checking for matches in the pattern.

for match in matches {
    for n in 0..<match.numberOfRanges{
        let range = match.rangeAtIndex(n)
        let r = phone.startIndex.advancedBy(range.location) ..<
            phone.startIndex.advancedBy(range.location+range.length)
            phone.substringWithRange(r)
        print(phone.substringWithRange(r)," Is this correct? Y or N?")
      
   }
    
}

//sets the welcome message loop
var y = true
var n = false
var answer:Bool

let rand = arc4random_uniform(100)
if(rand<50) {answer = true} else { answer = false}

if answer==true{
    print("Welcome to the Surgical Update Network")
    
}
else{
    print("Please enter phone number")
}

//Sprint 3
//After phone number confirmed, phone number is linked to MRN #, and basic patient information

class Patient  {
    var mrn: String = ""
    var fName: String = ""
    var lName: String = ""
    var contact: String = phone
    var currentStatus: surgicalCodes = surgicalCodes.test{
        didSet(oldStatus){
            print(currentStatus.rawValue)
        }
    }
    
    init(mrn: String, fName: String, lName: String, contact: String, currentStatus: surgicalCodes){
        self.mrn = mrn
        self.fName = fName
        self.lName = lName
        self.contact = contact
        self.currentStatus = currentStatus
    }
    
    func getStats() {
    print("\(self.fName) \(self.lName) : \(self.currentStatus.rawValue)")
    }
    
    func phoneStats() {
        print("\(self.contact) : \(self.currentStatus.rawValue)")
    }
}

//Sprint 4
//Set the arrays for the status updates

enum surgicalCodes: String{
    case test = "This message is a test. Please do no respond to this message"
    case A01 = "Patient is in the pre-surgical testing department"
    case A02 = "Patient has been taken to OR"
    case A03 = "Procedure has started"
    case A04 = "Procedure has competed"
    case A05 = "Patient is in recovery"
    case A06 = "Patient is being moved into room"
    case A07 = "Patient is ready for discharge"
    case A08 = "Please call ext 1234"

}


//Enter the patient information via app
var phoneMrn: [String:String] = [:]
var p = Patient.init(mrn: "a11111",fName: "Jason", lName: "Jones", contact: "5555555555", currentStatus: surgicalCodes.A01)
var p2 = Patient.init(mrn: "a11112",fName: "Sarah", lName: "Laughs", contact: "8155555555", currentStatus: surgicalCodes.A01)
var p3 = Patient.init(mrn: "a11113",fName: "Dorothy", lName: "Gail", contact: "6305555555", currentStatus: surgicalCodes.A01)


phoneMrn[phone]=p.mrn

for (key, value) in phoneMrn {
    print("\(key): \(value)")
}


p.currentStatus = surgicalCodes.A05
phoneMrn[phone]=p.mrn

//Sprint 5
//Pull it together
//This is for the back end documentation. Entered into the patient EMR using encounter number

var patientEMR: [String:Patient] = [:]

patientEMR["EN001"] = p
patientEMR["EN002"] = p2
patientEMR["EN003"] = p3

patientEMR["EN001"]?.currentStatus = surgicalCodes.A06

for (key, value) in patientEMR{
print("Encounter: \(key), Patient Name: \(value.fName) \(value.lName) \(value.contact) \(value.currentStatus.rawValue)")

}

p3.currentStatus = surgicalCodes.A07

p3.getStats()
p2.getStats()

p3.phoneStats()




